
ARCH_KEY="$(uname -m 2>/dev/null )"
[[ "${ARCH_KEY}" = "" ]] && ARCH_KEY="${ARCH}"


case "${ARCH_KEY}" in
aarch64|arm64)
return 0
;;
*)
echo "- 不支持的构架！"
rm -rf "${MODPATH}/mod/ads_monitor"
rm -rf "${MODPATH}/mod/mount_hosts"
;;
esac