#!/bin/sh

sleep 10s

if test "$(getprop ro.miui.ui.version.name)" = "" ;then 
	echo "非MIUI！"
	exit 0
fi

disable_list='
com.xiaomi.market/com.xiaomi.market.testsupport.DebugService
com.xiaomi.market/com.xiaomi.market.reverse_ad.wakeup.ReverseAdWakeUpService
com.xiaomi.market/com.xiaomi.market.reverse_ad.service.ReverseAdScheduleService
com.xiaomi.market/com.xiaomi.market.reverse_ad.page.WebReverseAdActivity
com.xiaomi.market/com.xiaomi.market.business_ui.directmail.SourceFileDownloadAdsActivity
'
enable_list='
com.xiaomi.market/com.xiaomi.gamecenter.preload.PreloadService
com.xiaomi.market/com.xiaomi.downloader.service.DownloadService
'

for target in ${disable_list} ;do
	pm disable "${target}" >/dev/null 2>&1
done

for target in ${enable_list}
do
	pm enable "${target}" >/dev/null 2>&1
done


find /data/user/*/com.xiaomi.market /data/data/com.xiaomi.market /data/media/*/Android/data/com.xiaomi.market -iname "cmsVideo" -type d -o -iname "*.log" -type f -o -iname "logs" -type d -o -iname "MiPushLog" -type d 2>/dev/null | while read adfile
do
	if test -e "${adfile}" ;then
		rm -rf "${adfile}"
		mkdir -p "${adfile%/*}"
		touch "${adfile}"
		chmod 000 "${adfile}"
	fi
done