#!/system/bin/sh
id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

ads_files=(
#微信小游戏广告
#没啥用，但是可以省内存
/data/media/[0-9]*/Android/data/com.tencent.mm/MicroMsg/wagamefiles/gamead
#书旗小说
/data/user/[0-9]*/com.shuqi.controller/files/noah_ads
/data/user/[0-9]*/com.shuqi.controller/files/flash_ad_image
)

for ads in ${ads_files[@]}
do
	mkdir_file "${ads}"
done
