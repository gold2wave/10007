#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/inotify.h>
#include <pthread.h>
#include <errno.h>
#include <dirent.h>
#include <stdio.h>

char *getParentDir(const char *path);

const char *skipPaths[] = {
    "/acct", "/odm_dlkm", "/apex", "/oem", "/bin", "/opconfig", "/cache", "/opcust", "/config", "/postinstall",
    "/cust", "/proc", "/d/", "/product", "/data_mirror", "/second_stage_resources", "/debug_ramdisk", "/dev", "/sys",
    "/etc", "/system", "/linkerconfig", "/system_ext", "/lost+found", "/tmp", "/metadata", "/vendor", "/mnt", "/vendor_dlkm", "/odm"
};
const int skipPathsCount = sizeof(skipPaths) / sizeof(skipPaths[0]);

const char *skipFullPaths[] = {
    "/data/user/", "/data/user", "/data/media/0/Android/data/", "/data/media/0/Android/data", "/data/data/", "/data/data",
    "/data", "/data/", "/data/media/0", "/data/media/0/", "/data/media/0/Downloa", "/data/media/0/Download/", "/data/media/0/Android",
    "/data/media/0/Android/", "/sdcard", "/sdcard/", "/sdcard/Download", "/sdcard/Download/", "/sdcard/Android", "/sdcard/Android/",
    "/storage", "/storage/", "/storage/emulated/0", "/storage/emulated/0/", "/storage/emulated/0/Download", "/storage/emulated/0/Download/",
    "/storage/emulated/0/Android", "/storage/emulated/0/Android/", "/"
};
const int skipFullPathsCount = sizeof(skipFullPaths) / sizeof(skipFullPaths[0]);

#define MAX_THREADS 8

typedef struct {
    char **data;
    size_t size;
    size_t capacity;
} StringArray;

void initStringArray(StringArray *arr) {
    arr->size = 0;
    arr->capacity = 4;
    arr->data = (char **)malloc(arr->capacity * sizeof(char *));
}

void appendStringArray(StringArray *arr, const char *str) {
    if (arr->size >= arr->capacity) {
        arr->capacity *= 2;
        arr->data = (char **)realloc(arr->data, arr->capacity * sizeof(char *));
    }
    arr->data[arr->size] = strdup(str);
    arr->size++;
}

void freeStringArray(StringArray *arr) {
    for (size_t i = 0; i < arr->size; i++) {
        free(arr->data[i]);
    }
    free(arr->data);
    arr->size = 0;
    arr->capacity = 0;
}

int shouldSkipPath(const char *path) {
    for (int i = 0; i < skipPathsCount; i++) {
        if (strncmp(path, skipPaths[i], strlen(skipPaths[i])) == 0) {
            return 1;
        }
    }
    for (int i = 0; i < skipFullPathsCount; i++) {
        if (strcmp(path, skipFullPaths[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

StringArray readConfigFile(const char *configFile) {
    StringArray filePaths;
    initStringArray(&filePaths);

    FILE *file = fopen(configFile, "r");
    if (!file) {
        fprintf(stderr, "无法打开配置文件: %s (%s)\n", configFile, strerror(errno));
        fflush(stderr);
        return filePaths;
    }

    char line[PATH_MAX];
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = 0;
        if (strlen(line) == 0 || line[0] == '#') continue;
        appendStringArray(&filePaths, line);
    }
    fclose(file);
    printf("配置文件读取完成，路径数: %zu\n", filePaths.size);
    fflush(stdout);
    return filePaths;
}

int createDirRecursively(const char *path) {
    char temp[PATH_MAX];
    char *pos = NULL;
    snprintf(temp, sizeof(temp), "%s", path);

    for (pos = temp + 1; *pos; pos++) {
        if (*pos == '/') {
            *pos = '\0';
            struct stat st;
            if (stat(temp, &st) != 0) {
                if (mkdir(temp, 0755) && errno != EEXIST) {  // 使用0755而不是0777
                    fprintf(stderr, "无法创建文件夹: %s (%s)\n", temp, strerror(errno));
                    fflush(stderr);
                    return -1;
                }
            }
            *pos = '/';
        }
    }
    struct stat st;
    if (stat(temp, &st) != 0) {
        if (mkdir(temp, 0755) && errno != EEXIST) {  // 使用0755而不是0777
            fprintf(stderr, "无法创建文件夹: %s (%s)\n", temp, strerror(errno));
            fflush(stderr);
            return -1;
        }
    }
    return 0;
}

int createFile(const char *filename, uid_t *orig_uid, gid_t *orig_gid) {
    printf("尝试创建文件: %s\n", filename);
    fflush(stdout);
    
    struct stat parent_st;
    char *parent_dir = getParentDir(filename);
    
    // 获取父目录信息
    if (stat(parent_dir, &parent_st) != 0) {
        fprintf(stderr, "无法获取父目录信息: %s (%s)\n", parent_dir, strerror(errno));
        fflush(stderr);
        free(parent_dir);
        return -1;
    }

    FILE *file = fopen(filename, "w");
    if (!file) {
        // 如果创建失败，尝试设置父目录为777
        if (chmod(parent_dir, 0777) != 0) {
            fprintf(stderr, "无法设置父目录权限为0777: %s (%s)\n", parent_dir, strerror(errno));
            fflush(stderr);
            free(parent_dir);
            return -1;
        }
        printf("父目录权限已设置为0777: %s\n", parent_dir);
        fflush(stdout);
        
        file = fopen(filename, "w");
        if (!file) {
            fprintf(stderr, "无法创建文件，即使父目录已设为777: %s (%s)\n", filename, strerror(errno));
            fflush(stderr);
            free(parent_dir);
            return -1;
        }
    }

    printf("文件已创建: %s\n", filename);
    fflush(stdout);
    fclose(file);

    // 设置文件的所有者与父目录一致
    if (chown(filename, parent_st.st_uid, parent_st.st_gid) != 0) {
        fprintf(stderr, "无法设置文件所有者: %s (%s)\n", filename, strerror(errno));
        fflush(stderr);
    } else {
        *orig_uid = parent_st.st_uid;
        *orig_gid = parent_st.st_gid;
        printf("文件所有者设置为: UID=%d, GID=%d: %s\n", parent_st.st_uid, parent_st.st_gid, filename);
        fflush(stdout);
    }

    // 设置文件权限为0000
    if (chmod(filename, 0000) != 0) {
        fprintf(stderr, "无法设置文件权限为0000: %s (%s)\n", filename, strerror(errno));
        fflush(stderr);
    } else {
        printf("文件权限已设置为0000: %s\n", filename);
        fflush(stdout);
    }

    free(parent_dir);
    return 0;
}

char *getParentDir(const char *path) {
    char *copy = strdup(path);
    char *lastSlash = strrchr(copy, '/');
    if (lastSlash && lastSlash != copy) {
        *lastSlash = '\0';
    } else {
        free(copy);
        return strdup("/");
    }
    return copy;
}

int removePathRecursive(const char *path) {
    struct stat st;
    if (lstat(path, &st) == -1) {
        fprintf(stderr, "无法访问路径: %s (%s)\n", path, strerror(errno));
        return -1;
    }

    if (S_ISDIR(st.st_mode)) {
        DIR *dir = opendir(path);
        if (!dir) {
            fprintf(stderr, "无法打开目录: %s (%s)\n", path, strerror(errno));
            return -1;
        }

        struct dirent *entry;
        while ((entry = readdir(dir)) != NULL) {
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
                continue;
            }

            char subPath[PATH_MAX];
            snprintf(subPath, sizeof(subPath), "%s/%s", path, entry->d_name);
            if (removePathRecursive(subPath) != 0) {
                closedir(dir);
                return -1;
            }
        }
        closedir(dir);

        if (rmdir(path) != 0) {
            fprintf(stderr, "无法删除目录: %s (%s)\n", path, strerror(errno));
            return -1;
        }
    } else {
        if (unlink(path) != 0) {
            fprintf(stderr, "无法删除文件: %s (%s)\n", path, strerror(errno));
            return -1;
        }
    }

    printf("路径已删除: %s\n", path);
    fflush(stdout);
    return 0;
}

int removePath(const char *path) {
    printf("删除路径: %s\n", path);
    fflush(stdout);
    return removePathRecursive(path);
}

void *monitorFile(void *arg) {
    char *filename = (char *)arg;
    printf("开始监控文件: %s\n", filename);
    fflush(stdout);

    uid_t orig_uid = 0;
    gid_t orig_gid = 0;
    
    // 如果文件存在，获取初始所有者信息
    struct stat initial_st;
    if (stat(filename, &initial_st) == 0) {
        orig_uid = initial_st.st_uid;
        orig_gid = initial_st.st_gid;
    }

    int inotifyFd = inotify_init();
    if (inotifyFd == -1) {
        fprintf(stderr, "无法初始化 inotify: %s (%s)\n", filename, strerror(errno));
        fflush(stderr);
        free(filename);
        return NULL;
    }

    int wd = inotify_add_watch(inotifyFd, filename, IN_DELETE_SELF | IN_MODIFY | IN_MOVE_SELF | IN_DELETE);
    if (wd == -1) {
        fprintf(stderr, "无法添加 inotify 监控: %s (%s)\n", filename, strerror(errno));
        fflush(stderr);
        close(inotifyFd);
        free(filename);
        return NULL;
    }

    char buf[4096] __attribute__((aligned(__alignof__(struct inotify_event))));
    ssize_t numRead;

    while (1) {
        numRead = read(inotifyFd, buf, sizeof(buf));
        if (numRead <= 0) {
            fprintf(stderr, "inotify 读取失败或关闭: %s (%s)\n", filename, strerror(errno));
            fflush(stderr);
            break;
        }

        for (char *ptr = buf; ptr < buf + numRead;) {
            struct inotify_event *event = (struct inotify_event *)ptr;
            printf("检测到文件事件: %s (mask: %u)\n", filename, event->mask);
            fflush(stdout);

            if (event->mask & (IN_DELETE_SELF | IN_MODIFY | IN_MOVE_SELF | IN_DELETE)) {
                char *dirPath = getParentDir(filename);
                
                if (stat(filename, &initial_st) != 0) {
                    printf("文件不存在，开始重建: %s\n", filename);
                    fflush(stdout);

                    removePath(filename);
                    if (createDirRecursively(dirPath) == 0) {
                        if (createFile(filename, &orig_uid, &orig_gid) != 0) {
                            fprintf(stderr, "文件重建失败: %s\n", filename);
                            fflush(stderr);
                        }
                    }
                }

                free(dirPath);
                usleep(100000);

                inotify_rm_watch(inotifyFd, wd);
                wd = inotify_add_watch(inotifyFd, filename, IN_DELETE_SELF | IN_MODIFY | IN_MOVE_SELF | IN_DELETE);
                if (wd == -1) {
                    fprintf(stderr, "无法重新添加 inotify 监控: %s (%s)\n", filename, strerror(errno));
                    fflush(stderr);
                    break;
                } else {
                    printf("成功重新添加监控: %s\n", filename);
                    fflush(stdout);
                }
            }
            ptr += sizeof(struct inotify_event) + event->len;
        }
    }

    close(inotifyFd);
    free(filename);
    printf("监控线程结束: %s\n", filename);
    fflush(stdout);
    return NULL;
}

int main(int argc, char *argv[]) {
    char *configFile = NULL;
    int opt;

    while ((opt = getopt(argc, argv, "f:")) != -1) {
        switch (opt) {
            case 'f':
                configFile = optarg;
                break;
            default:
                fprintf(stderr, "用法: %s -f <配置文件路径>\n", argv[0]);
                fflush(stderr);
                return 1;
        }
    }

    if (!configFile) {
        fprintf(stderr, "配置文件路径不能为空。\n");
        fflush(stderr);
        return 1;
    }

    StringArray filePaths = readConfigFile(configFile);
    if (filePaths.size == 0) {
        fprintf(stderr, "无法读取配置文件或文件为空: %s\n", configFile);
        fflush(stderr);
        return 1;
    }

    // 第一步：初始化所有路径
    for (size_t i = 0; i < filePaths.size; i++) {
        const char *filePath = filePaths.data[i];
        printf("初始化路径: %s\n", filePath);
        fflush(stdout);

        if (shouldSkipPath(filePath)) {
            printf("跳过路径: %s\n", filePath);
            fflush(stdout);
            continue;
        }

        char *dirPath = getParentDir(filePath);
        removePath(filePath);
        if (createDirRecursively(dirPath) == 0) {
            uid_t uid;
            gid_t gid;
            if (createFile(filePath, &uid, &gid) != 0) {
                fprintf(stderr, "初始化路径失败: %s\n", filePath);
                fflush(stderr);
            }
        }
        free(dirPath);
    }

    // 第二步：为所有路径创建监控线程
    size_t validPathCount = 0;
    for (size_t i = 0; i < filePaths.size; i++) {
        if (!shouldSkipPath(filePaths.data[i])) {
            validPathCount++;
        }
    }

    pthread_t *threads = (pthread_t *)malloc(validPathCount * sizeof(pthread_t));
    size_t threadCount = 0;

    // 创建所有线程
    for (size_t i = 0; i < filePaths.size; i++) {
        const char *filePath = filePaths.data[i];
        if (shouldSkipPath(filePath)) {
            continue;
        }

        char *filePathCopy = strdup(filePath);
        if (pthread_create(&threads[threadCount], NULL, monitorFile, filePathCopy) == 0) {
            threadCount++;
            printf("线程创建成功，路径: %s，总线程数: %zu\n", filePath, threadCount);
            fflush(stdout);
        } else {
            fprintf(stderr, "无法创建线程: %s (%s)\n", filePath, strerror(errno));
            fflush(stderr);
            free(filePathCopy);
        }
    }

    // 等待所有线程完成
    for (size_t i = 0; i < threadCount; i++) {
        pthread_join(threads[i], NULL);
        printf("线程 %zu 已结束\n", i);
        fflush(stdout);
    }

    free(threads);
    freeStringArray(&filePaths);
    printf("程序执行完成\n");
    fflush(stdout);
    return 0;
}
