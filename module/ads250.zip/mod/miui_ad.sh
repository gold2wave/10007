#!/system/bin/sh
#启用MIUI 11某个版本后的关闭系统广告的开关。
if test "$(getprop ro.miui.ui.version.name)" != "" ;then 
	settings put global passport_ad_status OFF
	settings put global com.android.thememanager.preferences.using_theme_show_ad false 
	pm disable com.android.thememanager/com.android.thememanager.ad.view.activity.AdWebViewActivity >/dev/null 2>&1
fi
