function Xiaomi_backup(){
local list='
a0.app.xiaomi.com
api.ad.xiaomi.com
globalapi.ad.xiaomi.com
'
local IFS=$'\n'
local cmd_backup="${1}"
test "${cmd_backup}" = "" && cmd_backup="disable"
for i in $list
do
#排除注释
test "$(echo "${i}" | grep -w '^#')" != "" && continue
	if test "${cmd_backup}" != "allow" ;then
		#小米云备份禁用
		iptables -D OUTPUT -m string --string "${i}" --algo bm --to 65535 -j DROP >/dev/null 2>&1
		iptables -A OUTPUT -m string --string "${i}" --algo bm --to 65535 -j DROP
	else
		#云备份启用
		iptables -D OUTPUT -m string --string "${i}" --algo bm --to 65535 -j DROP
	fi
done 
}



